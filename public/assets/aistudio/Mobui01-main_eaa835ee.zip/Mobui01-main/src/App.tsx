/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import MobileShell from './mobile/MobileShell';

export default function App() {
  return <MobileShell />;
}
